from pydantic import BaseModel, Field, EmailStr

class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length = 6)
    monthly_income: float = Field(gt=0)
    employment_type: str 

class UserLogin(BaseModel):
    email: EmailStr
    password: str 

class LoanApplicationCreate(BaseModel):
    loan_amount: float = Field(gt=0)
    purpose: str
    duration: int = Field(gt=0)

class LoanApproval(BaseModel):
    interest_rate : float = Field(gt=0)

class LoanRejection(BaseModel):
    rejected_reason : str

class EMIPayment(BaseModel):
    loan_id: int 
