from fastapi import Depends, HTTPException
from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials
)

from app.auth import auth
from app.database.user_db import user_db


security = HTTPBearer()


class UserDependencies:

    def get_current_user(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(security)
    ):

        token = credentials.credentials

        payload = auth.decode_access_token(token)

        if not payload:
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired token"
            )

        user = user_db.get_user_by_id(
            payload["user_id"]
        )

        if not user:
            raise HTTPException(
                status_code=401,
                detail="User not found"
            )

        return user


    def get_customer(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(security)
    ):

        current_user = self.get_current_user(
            credentials
        )

        if current_user["role"] != "CUSTOMER":
            raise HTTPException(
                status_code=403,
                detail="Customer access required"
            )

        return current_user


    def get_admin(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(security)
    ):

        current_user = self.get_current_user(
            credentials
        )

        if current_user["role"] != "ADMIN":
            raise HTTPException(
                status_code=403,
                detail="Admin access required"
            )

        return current_user


user_dependencies = UserDependencies()