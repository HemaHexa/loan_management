from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database.init_db import create_table

from app.routers import auth_rout
from app.routers import applications
from app.routers import loans
from app.routers import payments
from app.routers import admin


app = FastAPI(
    title="Personal Loan Management System",
    version="1.0.0"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


create_table()


app.include_router(auth_rout.router)
app.include_router(applications.router)
app.include_router(loans.router)
app.include_router(payments.router)
app.include_router(admin.router)


@app.get("/")
def home():
    return {
        "message": "Personal Loan Management System API is running"
    }