from datetime import timezone, datetime, timedelta

import jwt
from pwdlib import PasswordHash

from app.config import config


class Auth:

    def __init__(self):
        self.password_hash = PasswordHash.recommended()


    def hash_password(self, password):

        return self.password_hash.hash(password)


    def verify_password(
        self,
        plain_password,
        hashed_password
    ):

        return self.password_hash.verify(
            plain_password,
            hashed_password
        )


    def create_access_token(
        self,
        user_id,
        role
    ):

        expiry = (
            datetime.now(timezone.utc)
            + timedelta(
                minutes=config.ACCESS_TOKEN_EXPIRE_MINUTES
            )
        )

        data = {
            "user_id": user_id,
            "role": role,
            "exp": expiry
        }

        token = jwt.encode(
            data,
            config.SECRET_KEY,
            algorithm=config.ALGORITHM
        )

        return token


    def decode_access_token(self, token):

        try:
            return jwt.decode(
                token,
                config.SECRET_KEY,
                algorithms=[config.ALGORITHM]
            )

        except jwt.ExpiredSignatureError:
            return None

        except jwt.InvalidTokenError:
            return None


auth = Auth()