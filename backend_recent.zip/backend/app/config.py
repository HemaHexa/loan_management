import os
from dotenv import load_dotenv

load_dotenv()


class Config:

    def __init__(self):

        self.SECRET_KEY = os.getenv("SECRET_KEY")

        self.ALGORITHM = os.getenv(
            "ALGORITHM",
            "HS256"
        )

        self.ACCESS_TOKEN_EXPIRE_MINUTES = int(
            os.getenv(
                "ACCESS_TOKEN_EXPIRE_MINUTES",
                "60"
            )
        )


config = Config()