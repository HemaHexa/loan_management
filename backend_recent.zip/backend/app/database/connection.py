import sqlite3

class Database:

    def __init__(self):
        self.database_name = "personal_loan.db"

    def get_connection(self):
        conn = sqlite3.connect(self.database_name)
        # Get the tuples changed to the dict for passing easier to JSON
        conn.row_factory = sqlite3.Row
        # To enable foreign-key relationships
        conn.execute("PRAGMA foreign_keys = ON")

        return conn

db = Database()