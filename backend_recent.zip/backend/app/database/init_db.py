from app.database.connection import db

def create_table():
    conn = db.get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user(
            id INTEGER PRIMARY KEY AUTOINCREMENT ,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL
                CHECK(role IN('CUSTOMER','ADMIN')),
            monthly_income REAL ,
            employment_type TEXT ,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS loan_application(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            loan_amount INTEGER NOT NULL,
            purpose TEXT NOT NULL,
            duration INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT "Pending"
                CHECK(status IN("Pending", "Rejected", "Approved")),
            rejected_reason TEXT NOT NULL,
            applied_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY(user_id)
                REFERENCES user(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS loans(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            principal_amount REAL NOT NULL,
            interest_rate REAL NOT NULL,
            duration_months INTEGER NOT NULL,
            emi_amount REAL NOT NULL,
            remaining_emi INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT "Active"
                CHECK(status IN("Active","Completed")),
            approved_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY(application_id)
                REFERENCES loan_application(id)

            FOREIGN KEY(user_id)
                REFERENCES user(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS emi_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            loan_id INTEGER NOT NULL,
            emi_no INTEGER NOT NULL,
            amount REAL NOT NULL,
            payment_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT "Paid"
                CHECK(status IN("Paid")),

            FOREIGN KEY(loan_id)
                REFERENCES loans(id)

            UNIQUE(loan_id,emi_no)
        )
    """)

    conn.commit()
    conn.close()
    print("Created the database successfully")

if __name__ == "__main__":
    create_table()

