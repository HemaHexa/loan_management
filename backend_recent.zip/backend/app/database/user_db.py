from app.database.connection import db

class Userdb:

    def create_user( self, name, email, password_hash, role, monthly_income, employment_type):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            INSERT INTO user (
                name,
                email,
                password_hash,
                role,
                monthly_income,
                employment_type
            ) VALUES (?,?,?,?,?,?)
        """, (
            name,
            email,
            password_hash,
            role,
            monthly_income,
            employment_type
        )
        )
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        return user_id

    def get_by_user_id(self,user_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("SELECT * FROM user WHERE user_id = ? ", (user_id, ))
        conn.commit()
        user = cursor.fetchone()
        conn.close()
        return user

    def get_by_email(self,email):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("SELECT * FROM user WHERE email = ?", (email, ))
        conn.commit()
        user=cursor.fetchone()
        conn.close()
        return user

user_db = Userdb()