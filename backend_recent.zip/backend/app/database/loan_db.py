from app.database.connection import db

class Loandb:

    def create_laon(self, applicatioon_id, user_id, principal_amount, interest_rate, duration_months, emi_amount):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO loans(
                application_id,
                user_id,
                principal_amount,
                interest_rate,
                duration_moonths,
                emi_amount,
                remaining_emi,
                status
            ) VALUES (?,?,?,?,?,?.?,"Active")
        """,
        (applicatioon_id,
         user_id,
         principal_amount,
         interest_rate,
         duration_months,
         emi_amount,
         duration_months))

        conn.commit()
        loan_id = cursor.lastrowid
        conn.close()
        return loan_id

    def get_loan_by_id(self, loan_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("SELECT * FROM loans WHERE id =?", (loan_id, ))
        conn.commit()
        loan=cursor.fetchone()
        conn.close()
        return loan

    def get_active_loan_by_user(self, user_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""SELECT * FROM loans WHERE user_id =? AND status = "Active" ORDERBY approved_date DESC LIMIT 1""", (user_id, ))
        conn.commit()
        loan=cursor.fetchone()
        conn.close()
        return loan


    def get_all_loans(self):
        conn=db.get_connetion()
        cursor=conn.cursor()
        cursor.execute("""
            SELECT * FROM loans l
            JOIN user u 
            ON l.user_id = u.id
            ORDERBY approved_date DESC
        """)
        conn.commit()
        loans=cursor.fetchall()
        conn.close()
        return loans

    def reduce_remaining_emi(self, loan_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            UPDATE loans
            SET remaining_emi = remaining_emi - 1
            WHERE id = ?
            AND STATUS = "Active"
            AND remaining_emi > 0
        """, (loan_id, ))
        conn.commit()
        success = cursor.rowcount > 0
        conn.close()
        return success

    def complete_loan(self, loan_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            UPDATE loans
            SET status = "Completed"
            WHERE id = ?
            AND remaining_emi = 0
        """, (loan_id, ))
        conn.commit()
        success = cursor.rowcount > 0
        conn.close()
        return success

loan_db = Loandb()