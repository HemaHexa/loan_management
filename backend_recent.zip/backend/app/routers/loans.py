from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import user_dependencies
from app.database.loan_db import loan_db


router = APIRouter(
    prefix="/api/loans",
    tags=["Loans"]
)


@router.get("/my")
def my_loan(
    current_user=Depends(
        user_dependencies.get_customer
    )
):

    loan = loan_db.get_active_loan_by_user(
        current_user["id"]
    )

    if not loan:
        raise HTTPException(
            status_code=404,
            detail="No active loan found"
        )

    return dict(loan)