from fastapi import APIRouter, HTTPException

from app.schemas import UserRegister, UserLogin
from app.services.auth_service import auth_service


router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"]
)


@router.post("/register")
def register(data: UserRegister):

    try:
        user_id = auth_service.register_user(
            data.name,
            data.email,
            data.password,
            data.monthly_income,
            data.employment_type
        )

        return {
            "message": "Registration successful",
            "user_id": user_id
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


@router.post("/login")
def login(data: UserLogin):

    try:
        return auth_service.login_user(
            data.email,
            data.password
        )

    except ValueError as error:
        raise HTTPException(
            status_code=401,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )