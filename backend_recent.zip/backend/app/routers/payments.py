from fastapi import APIRouter, Depends, HTTPException

from app.schemas import EMIPayment
from app.dependencies import user_dependencies
from app.services.emi_service import emi_service
from app.database.payment_db import paydb


router = APIRouter(
    prefix="/api/payments",
    tags=["EMI Payments"]
)


@router.post("/pay")
def pay_emi(
    data: EMIPayment,
    current_user=Depends(
        user_dependencies.get_customer
    )
):

    try:
        result = emi_service.pay_emi(
            data.loan_id,
            current_user["id"]
        )

        return {
            "message": "EMI paid successfully",
            **result
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


@router.get("/history")
def payment_history(
    current_user=Depends(
        user_dependencies.get_customer
    )
):

    from app.database.loan_db import loan_db

    loan = loan_db.get_active_loan_by_user(
        current_user["id"]
    )

    if not loan:
        return []

    payments = payment_db.get_payments_by_loan(
        loan["id"]
    )

    return [
        dict(payment)
        for payment in payments
    ]