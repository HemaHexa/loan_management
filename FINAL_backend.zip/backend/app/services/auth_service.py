import sqlite3
from app.auth import auth
from app.database.user_db import user_db

class AuthService:
    def register_user( self, name, email, password, monthly_income, employment_type ):
        try:
            existing_user = user_db.get_by_email(email)
            if existing_user:
                raise ValueError("Email is already registered")
            # Hashing password
            password_hash = auth.hash_password(password)
            # Store the HASH, not the original password
            user_id = user_db.create_user(
                name=name,
                email=email,
                password_hash=password_hash,
                role="CUSTOMER",
                monthly_income=monthly_income,
                employment_type=employment_type
            )
            return user_id

        except sqlite3.Error as error:
            raise RuntimeError(f"Database error: {error}")

    def login_user(self, email, password):
        try:
            user = user_db.get_by_email(email)
            if not user:
                raise ValueError("Invalid email or password")
            password_valid = auth.verify_password(
                password,
                user["password_hash"]
            )
            if not password_valid:
                raise ValueError("Invalid email or password")
            token = auth.create_access_token(
                user["id"],
                user["role"]
            )
            return {
                "access_token": token,
                "token_type": "bearer",
                "role": user["role"]
            }

        except sqlite3.Error as error:
            raise RuntimeError(
                f"Database error: {error}"
            )

auth_service = AuthService()