from fastapi import APIRouter, Depends, HTTPException
from app.schemas import LoanApplicationCreate
from app.dependencies import user_dependencies
from app.services.loan_service import loan_service
from app.database.application_db import app_db

router = APIRouter(
    prefix="/api/applications",
    tags=["Loan Applications"]
)


@router.post("")
def apply_for_loan(
    data: LoanApplicationCreate,
    current_user=Depends(
        user_dependencies.get_customer
    )
):

    try:
        application_id = (
            loan_service.create_application(
                current_user["id"],
                data.loan_amount,
                data.purpose,
                data.duration
            )
        )

        return {
            "message":
                "Loan application submitted successfully",
            "application_id": application_id,
            "status": "PENDING"
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


@router.get("/my")
def my_applications(
    current_user=Depends(
        user_dependencies.get_customer
    )
):

    applications = (
        app_db.get_applications_by_user(
            current_user["id"]
        )
    )

    return [
        dict(application)
        for application in applications
    ]