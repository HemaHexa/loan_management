from app.database.connection import db

class Paymentdb:

    def create_payment(self, loan_id, emi_no, amount):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO emi_payments (
            loan_id,
            emi_no,
            amount,
            status
            ) VALUES (?,?,?,"Paid")
        """, (
                loan_id,
                emi_no,
                amount
        ))
        conn.commit()
        pay_id = cursor.lastrowid
        conn.close()
        return pay_id

    def get_payments_by_loan(self, loan_id):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM emi_payments WHERE loan_id = ?", (loan_id, ))
        conn.commit()
        emi = cursor.fetchone()
        conn.close()
        return emi

    def get_all_payments(self):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM emi_payments e
            JOIN loans l
            ON e.loan_id = l.id
            JOIN user u
            ON l.user_id = u.id
            ORDER BY payment_date DESC
        """)
        conn.commit()
        emis= cursor.fetchall()
        conn.close()
        return emis 

    def get_payment_count(self, loan_id):
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) AS Total
            FROM emi_payments WHERE loan_id = ?
        """, (loan_id, ))
        conn.commit()
        res = cursor.fetchone()
        conn.close()
        return res["total"]

paydb = Paymentdb()