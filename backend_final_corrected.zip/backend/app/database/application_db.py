from app.database.connection import db 

class Applicationdb:
    
    def create_application( self, user_id, loan_amount, purpose, duration):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            INSERT INTO loan_application (
                user_id,
                loan_amount,
                purpose,
                duration,
                status
            ) VALUES ( ?,?,?,?,"Pending") 
        """, ( 
            user_id, 
            loan_amount, 
            purpose, 
            duration)
        )
        conn.commit()
        application_id = cursor.lastrowid
        conn.close()
        return application_id
    
    def get_application_by_id(self, application_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("SELECT * FROM loan_application WHERE id = ?", (application_id, ))
        conn.commit()
        application=cursor.fetchone()
        conn.close()
        return application

    def get_applications_by_user(self, user_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("SELECT * FROM loan_application WHERE user_id = ? ORDER BY applied_date DESC", (user_id, ))
        conn.commit()
        applications=cursor.fetchall()
        conn.close()
        return applications

    def get_all_applications(self):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            SELECT * FROM loan_application la
            JOIN user u
            ON la.user_id = u.id
            ORDER BY la.applied_date DESC
        """)
        conn.commit()
        applications=cursor.fetchall()
        conn.close()
        return applications

    def get_pending_applications(self):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            SELECT * FROM loan_application la
            JOIN user u
            ON la.user_id = u.id
            WHERE la.status = 'Pending'
            ORDER BY la.applied_date DESC
        """)
        conn.commit()
        pend_app=cursor.fetchall()
        conn.close()
        return pend_app

    def approve_application(self,application_id):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            UPDATE loan_application
            SET 
                status="Approved",
                rejected_reason=NULL
            WHERE id = ?
            AND status = 'Pending'
        """, (application_id, ))
        conn.commit()
        success = cursor.rowcount > 0
        conn.close()
        return success

    def reject_application(self, application_id, rejected_reason):
        conn=db.get_connection()
        cursor=conn.cursor()
        cursor.execute("""
            UPDATE loan_application
            SET 
                status = "Rejected",
                rejection_reason= ?
            WHERE id = ?
        """, (self.reject_reason, application_id, ))
        conn.commit()
        success = cursor.rowcount > 0
        conn.close()
        return success

app_db = Applicationdb()
    
