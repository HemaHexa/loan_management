from fastapi import APIRouter, Depends, HTTPException
from app.dependencies import user_dependencies
from app.schemas import LoanApproval, LoanRejection
from app.services.loan_service import loan_service
from app.database.application_db import app_db
from app.database.loan_db import loan_db
from app.database.payment_db import paydb

router = APIRouter(
    prefix="/api/admin",
    tags=["Admin"]
)

@router.get("/applications")
def get_applications(
    admin=Depends(
        user_dependencies.get_admin
    )
):

    applications = (
        app_db.get_all_applications()
    )

    return [
        dict(application)
        for application in applications
    ]


@router.get("/applications/{application_id}")
def get_application(
    application_id: int,
    admin=Depends(
        user_dependencies.get_admin
    )
):

    application = (
        app_db.get_application_by_id(
            application_id
        )
    )

    if not application:
        raise HTTPException(
            status_code=404,
            detail="Application not found"
        )

    return dict(application)


@router.put(
    "/applications/{application_id}/approve"
)
def approve_application(
    application_id: int,
    data: LoanApproval,
    admin=Depends(
        user_dependencies.get_admin
    )
):

    try:
        result = loan_service.approve_application(
            application_id,
            data.interest_rate
        )

        return {
            "message":
                "Loan application approved successfully",
            **result
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


@router.put(
    "/applications/{application_id}/reject"
)
def reject_application(
    application_id: int,
    data: LoanRejection,
    admin=Depends(
        user_dependencies.get_admin
    )
):

    try:
        loan_service.reject_application(
            application_id,
            data.rejection_reason
        )

        return {
            "message":
                "Loan application rejected successfully"
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except RuntimeError as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )


@router.get("/loans")
def get_loans(
    admin=Depends(
        user_dependencies.get_admin
    )
):

    loans = loan_db.get_all_loans()

    return [
        dict(loan)
        for loan in loans
    ]


@router.get("/payments")
def get_payments(
    admin=Depends(
        user_dependencies.get_admin
    )
):

    payments = paydb.get_all_payments()

    return [
        dict(payment)
        for payment in payments
    ]