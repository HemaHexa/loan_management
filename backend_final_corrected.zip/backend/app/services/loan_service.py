import sqlite3 

from app.database.application_db import app_db
from app.database.loan_db import loan_db

class LoanService:
    def create_application(self, user_id, loan_amount, purpose, duration_months):

        try:
            active_loan = loan_db.get_active_loan_by_user(user_id)

            if active_loan:
                raise ValueError("You already have an active loan")

            application_id = ( app_db.create_application( user_id, loan_amount, purpose, duration_months))

            return application_id
        
        except sqlite3.Error as error:
            raise RuntimeError(f"Database error: {error}")

    def calculate_emi(self, principal, annual_interest_rate, months):
        monthly_rate = (annual_interest_rate/12/100)

        if monthly_rate == 0:
            return round(principal / months, 2)

        emi = (principal * monthly_rate * ( 1 + monthly_rate ) ** months) / ( (1 + monthly_rate ) ** months - 1 )

        return round(emi,2)

    def approve_application(self, application_id, interest_rate):
        try:
            application = app_db.get_application_by_id(application_id)

            if not application:
                raise ValueError("Application not found")

            if application["status"] != "Pending":
                raise ValueError("Application is already processed")

            emi_amount = self.calculate_emi( application["loan_amount"],interest_rate,application["duration"])

            approved = ( app_db.approve_application( application_id))

            if not approved:
                raise ValueError("Unable to approve application")

            loan_id = loan_db.create_laon(
                application_id=application_id,
                user_id=application["user_id"],
                principal_amount=application["loan_amount"],
                interest_rate=interest_rate,
                duration_months=application["duration"],
                emi_amount=emi_amount
            )

            return {
                "loan_id": loan_id,
                "emi_amount": emi_amount
            }

        except sqlite3.Error as error:
            raise RuntimeError(f"Database error: {error}")

    def reject_application(self, application_id, rejection_reason):
        try:
            application = app_db.get_application_by_id(application_id)

            if not application:
                raise ValueError("Application not found")

            if application["status"] != "Pending":
                raise ValueError("Application is already processed")

            success = ( app_db.reject_application(application_id, rejection_reason))

            return success

        except sqlite3.Error as error:
            raise RuntimeError(f"Database error: {error}")

loan_service = LoanService()