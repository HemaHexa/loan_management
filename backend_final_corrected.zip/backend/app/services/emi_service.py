import sqlite3

from app.database.loan_db import loan_db
from app.database.payment_db import paydb

class EMIService:

    def pay_emi(self, loan_id, user_id):

        try:
            loan = loan_db.get_loan_by_id(loan_id)

            if not loan:
                raise ValueError("Loan not found")

            if loan["user_id"] != user_id:
                raise ValueError("This loan does not belong to you")

            if loan["status"] != "Active":
                raise ValueError("LOan is not active")

            if loan["remaining_emi"] <= 0:
                raise ValueError("No EMI payment is pending")

            paid_count = ( paydb.get_payment_count(loan_id))

            emi_no = paid_count + 1

            payment_id = paydb.create_payment(
                loan_id=loan_id,
                emi_no=emi_no,
                amount=loan["emi_amount"]
            )

            loan_db.reduce_remaining_emi(loan_id)

            updated_loan = loan_db.get_loan_by_id(loan_id)

            if updated_loan["remaining_emi"] == 0:
                loan_db.complete_loan(loan_id)

            return {
                "payment_id": payment_id,
                "emi_no": emi_no,
                "amount": loan["emi_amount"]
            }
        
        except sqlite3.Error as error:
            raise RuntimeError (f"Database error: {error}")

emi_service = EMIService()
