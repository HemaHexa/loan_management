import sqlite3

DB_PATH = "personal_loan.db"

class Database:

    def __init__(self):
        self.database_name = "personal_loan.db"

    def get_db_connection(self):
        conn = sqlite3.connect(self.database_name)
        #Its is used to convert tuple to dict to perform easy API function
        conn.row_factory = sqlite3.Row
        #It allows the SQLite library to modify its property
        conn.execute("PRAGMA foreign_key=ON")

        return conn

db = Database()